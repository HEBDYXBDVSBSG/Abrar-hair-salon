ABRAR HAIR SALON WEBSITE

Preview: open index.html in a web browser. The website is responsive and built as a static HTML page.

Before publishing:
- Replace sample testimonial copy with real, verified customer reviews.
- Confirm the business address and opening hours.
- Replace the generic social profile links with Abrar Hair Salon's official Instagram, Facebook and TikTok URLs.
- Service prices say “Ask us” because prices were not provided.

External Google Fonts and Unsplash images require internet access.
